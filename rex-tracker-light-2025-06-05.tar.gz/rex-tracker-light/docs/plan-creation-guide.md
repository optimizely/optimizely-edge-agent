# Rex Tracker Light - Plan Creation Guide

This guide explains how to create effective, prescriptive implementation plans that eliminate ambiguity and ensure consistent execution.

## Table of Contents

1. [Plan Creation Philosophy](#plan-creation-philosophy)
2. [Pre-Planning Phase](#pre-planning-phase)
3. [Creating Prescriptive Tasks](#creating-prescriptive-tasks)
4. [Writing Atomic Actions](#writing-atomic-actions)
5. [Defining Verification Criteria](#defining-verification-criteria)
6. [Common Patterns](#common-patterns)
7. [Plan Validation](#plan-validation)
8. [Examples](#examples)

## Plan Creation Philosophy

### Core Principles

1. **Be Prescriptive, Not Descriptive**
   - ❌ "Add authentication to the API"
   - ✅ "Create JWT middleware using jsonwebtoken@9.0.2 with RS256 algorithm"

2. **Remove All Ambiguity**
   - Every decision should be made during planning
   - No architectural choices during implementation
   - Exact versions, exact patterns, exact locations

3. **Think Like a Recipe**
   - List every ingredient (package)
   - Specify every step
   - Define what success looks like

4. **Plan for Robots**
   - If an AI or junior developer can't implement it exactly, it's not detailed enough

## Pre-Planning Phase

Before creating a plan, gather:

### 1. Requirements
- What problem does this solve?
- What are the acceptance criteria?
- What are the constraints?

### 2. Technical Decisions
- Which packages/libraries to use?
- What patterns to follow?
- What naming conventions?

### 3. Architecture Context
- Where does this fit in the system?
- What existing code will it interact with?
- What future changes might affect it?

### 4. Example Checklist
```markdown
Pre-Planning Checklist for Authentication System:
- [ ] Authentication method: JWT
- [ ] Token algorithm: RS256
- [ ] Token expiry: 24 hours
- [ ] Library: jsonwebtoken@9.0.2
- [ ] Middleware location: src/middleware/auth.ts
- [ ] Error response format: { error: string, code: string }
- [ ] Protected routes pattern: /api/protected/*
- [ ] Public routes: /api/auth/*, /api/public/*
```

## Creating Prescriptive Tasks

### Task Structure

Each task needs:

```json
{
  "id": "TASK001",
  "title": "Create JWT authentication middleware",
  "description": "Implement Express middleware that validates JWT tokens for protected routes",
  "prescriptiveDetails": {
    "summary": "Middleware that extracts and validates JWT tokens from Authorization header",
    
    "requiredPackages": [
      {
        "name": "jsonwebtoken",
        "version": "9.0.2",
        "installCommand": "npm install jsonwebtoken@9.0.2"
      },
      {
        "name": "@types/jsonwebtoken",
        "version": "9.0.1",
        "installCommand": "npm install -D @types/jsonwebtoken@9.0.1"
      }
    ],
    
    "targetFiles": [
      {
        "path": "src/middleware/auth.ts",
        "action": "CREATE",
        "description": "Main authentication middleware"
      },
      {
        "path": "src/types/express.d.ts",
        "action": "CREATE",
        "description": "TypeScript declaration for Request extension"
      }
    ],
    
    "codePatterns": [
      {
        "file": "src/middleware/auth.ts",
        "description": "Complete middleware implementation",
        "language": "typescript",
        "pattern": "import { Request, Response, NextFunction } from 'express';\nimport jwt from 'jsonwebtoken';\nimport { AuthUser } from '../types/auth';\n\nexport interface AuthRequest extends Request {\n  user?: AuthUser;\n}\n\nexport const authMiddleware = async (\n  req: AuthRequest,\n  res: Response,\n  next: NextFunction\n): Promise<void> => {\n  try {\n    const token = req.headers.authorization?.split(' ')[1];\n    \n    if (!token) {\n      res.status(401).json({ \n        error: 'No token provided',\n        code: 'AUTH_TOKEN_MISSING' \n      });\n      return;\n    }\n    \n    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as AuthUser;\n    req.user = decoded;\n    next();\n  } catch (error) {\n    if (error instanceof jwt.TokenExpiredError) {\n      res.status(401).json({ \n        error: 'Token expired',\n        code: 'AUTH_TOKEN_EXPIRED' \n      });\n    } else if (error instanceof jwt.JsonWebTokenError) {\n      res.status(401).json({ \n        error: 'Invalid token',\n        code: 'AUTH_TOKEN_INVALID' \n      });\n    } else {\n      res.status(500).json({ \n        error: 'Authentication error',\n        code: 'AUTH_ERROR' \n      });\n    }\n  }\n};"
      }
    ],
    
    "environmentVariables": [
      {
        "name": "JWT_SECRET",
        "description": "Secret key for JWT signing",
        "example": "your-256-bit-secret",
        "required": true
      }
    ],
    
    "constraints": [
      "Do NOT use passport.js or any other auth library",
      "Do NOT implement refresh tokens in this task",
      "Do NOT add rate limiting",
      "Do NOT modify existing Express app configuration",
      "Must preserve existing error response format"
    ]
  }
}
```

### Key Elements

1. **Required Packages**: Exact versions, no ranges
2. **Code Patterns**: Complete, working code - not snippets
3. **Target Files**: Exact paths and whether to create or modify
4. **Constraints**: What NOT to do is as important as what to do

## Writing Atomic Actions

### Decomposition Process

1. **Start with the end goal**
2. **Work backwards to prerequisites**
3. **Break down until each step is singular**
4. **Order by dependencies**

### Example Decomposition

Task: "Create authentication middleware"

```json
"atomicActions": [
  {
    "id": "ACTION001",
    "description": "Install jsonwebtoken package version 9.0.2",
    "completed": false
  },
  {
    "id": "ACTION002", 
    "description": "Install @types/jsonwebtoken package version 9.0.1 as dev dependency",
    "completed": false
  },
  {
    "id": "ACTION003",
    "description": "Create directory src/middleware if it doesn't exist",
    "completed": false
  },
  {
    "id": "ACTION004",
    "description": "Create file src/middleware/auth.ts",
    "completed": false
  },
  {
    "id": "ACTION005",
    "description": "Add imports: express types (Request, Response, NextFunction)",
    "completed": false
  },
  {
    "id": "ACTION006",
    "description": "Add import: jsonwebtoken default import",
    "completed": false
  },
  {
    "id": "ACTION007",
    "description": "Add import: AuthUser type from ../types/auth",
    "completed": false
  },
  {
    "id": "ACTION008",
    "description": "Define AuthRequest interface extending Request with optional user property",
    "completed": false
  },
  {
    "id": "ACTION009",
    "description": "Create authMiddleware function with proper TypeScript signature",
    "completed": false
  },
  {
    "id": "ACTION010",
    "description": "Add token extraction logic from Authorization header",
    "completed": false
  },
  {
    "id": "ACTION011",
    "description": "Add missing token error response (401, AUTH_TOKEN_MISSING)",
    "completed": false
  },
  {
    "id": "ACTION012",
    "description": "Add JWT verification with process.env.JWT_SECRET",
    "completed": false
  },
  {
    "id": "ACTION013",
    "description": "Assign decoded token to req.user",
    "completed": false
  },
  {
    "id": "ACTION014",
    "description": "Add next() call for successful authentication",
    "completed": false
  },
  {
    "id": "ACTION015",
    "description": "Add catch block for token verification errors",
    "completed": false
  },
  {
    "id": "ACTION016",
    "description": "Add specific error handling for TokenExpiredError",
    "completed": false
  },
  {
    "id": "ACTION017",
    "description": "Add specific error handling for JsonWebTokenError",
    "completed": false
  },
  {
    "id": "ACTION018",
    "description": "Add generic error handling for other errors",
    "completed": false
  },
  {
    "id": "ACTION019",
    "description": "Export authMiddleware as named export",
    "completed": false
  },
  {
    "id": "ACTION020",
    "description": "Add JWT_SECRET to .env.example with placeholder value",
    "completed": false
  }
]
```

### Atomic Action Best Practices

1. **One verb per action**: Install, Create, Add, Define, Update
2. **Specific targets**: Which file, which line, which function
3. **Verifiable outcome**: Can you check if it's done?
4. **No conjunctions**: No "and", "then", "also"

## Defining Verification Criteria

### Types of Criteria

1. **File Existence**
   ```json
   "File src/middleware/auth.ts exists"
   ```

2. **Code Presence**
   ```json
   "authMiddleware function is exported from auth.ts"
   ```

3. **Package Installation**
   ```json
   "package.json contains jsonwebtoken@9.0.2"
   ```

4. **Behavior Tests**
   ```json
   "Middleware returns 401 when no token provided"
   ```

5. **Integration Points**
   ```json
   "Middleware can be applied to Express routes"
   ```

### Complete Example

```json
"verificationCriteria": [
  "File src/middleware/auth.ts exists and exports authMiddleware function",
  "TypeScript compilation succeeds without errors",
  "package.json includes jsonwebtoken@9.0.2 in dependencies",
  "package.json includes @types/jsonwebtoken@9.0.1 in devDependencies",
  "Middleware returns 401 with code AUTH_TOKEN_MISSING when no token",
  "Middleware returns 401 with code AUTH_TOKEN_EXPIRED for expired tokens",
  "Middleware returns 401 with code AUTH_TOKEN_INVALID for invalid tokens",
  "Middleware adds user object to request for valid tokens",
  "Middleware calls next() for valid tokens",
  "All error responses match format: { error: string, code: string }"
]
```

## Common Patterns

### API Endpoint Pattern

```json
{
  "prescriptiveDetails": {
    "apiSpecifications": [
      {
        "method": "POST",
        "path": "/api/auth/login",
        "description": "User login endpoint",
        "requestBody": {
          "type": "object",
          "required": ["email", "password"],
          "properties": {
            "email": { "type": "string", "format": "email" },
            "password": { "type": "string", "minLength": 8 }
          }
        },
        "responseBody": {
          "type": "object",
          "properties": {
            "token": { "type": "string" },
            "user": {
              "type": "object",
              "properties": {
                "id": { "type": "string" },
                "email": { "type": "string" },
                "name": { "type": "string" }
              }
            }
          }
        },
        "headers": {
          "Content-Type": "application/json"
        }
      }
    ]
  }
}
```

### Database Schema Pattern

```json
{
  "prescriptiveDetails": {
    "dataSchemas": [
      {
        "name": "User",
        "description": "User model for authentication",
        "schema": {
          "id": "string (UUID)",
          "email": "string (unique, indexed)",
          "passwordHash": "string",
          "firstName": "string",
          "lastName": "string", 
          "createdAt": "DateTime",
          "updatedAt": "DateTime",
          "lastLoginAt": "DateTime (nullable)"
        },
        "implementation": "Prisma model in schema.prisma"
      }
    ]
  }
}
```

### Configuration Pattern

```json
{
  "prescriptiveDetails": {
    "configurationFiles": [
      {
        "file": "config/auth.config.ts",
        "content": {
          "jwtSecret": "process.env.JWT_SECRET!",
          "jwtExpiresIn": "24h",
          "bcryptRounds": 10,
          "passwordMinLength": 8,
          "passwordRequireSpecialChar": true
        }
      }
    ]
  }
}
```

## Plan Validation

Before finalizing a plan, validate:

### Completeness Checklist

- [ ] Every task has prescriptive details
- [ ] All dependencies are specified with versions
- [ ] File paths are absolute from project root
- [ ] Code patterns compile/run without modification
- [ ] Atomic actions cover entire implementation
- [ ] Verification criteria are measurable
- [ ] Constraints are clear and specific

### Common Issues to Check

1. **Vague Descriptions**
   - ❌ "Set up error handling"
   - ✅ "Add try-catch block around JWT verification with specific error types"

2. **Missing Versions**
   - ❌ "Install jsonwebtoken"
   - ✅ "Install jsonwebtoken@9.0.2"

3. **Incomplete Code Patterns**
   - ❌ Code snippet that references undefined variables
   - ✅ Complete, standalone code that works when pasted

4. **Ambiguous Paths**
   - ❌ "Create in middleware folder"
   - ✅ "Create at src/middleware/auth.ts"

## Examples

### Example 1: Simple Configuration Task

```json
{
  "id": "TASK_CONFIG_001",
  "title": "Add environment variables for authentication",
  "prescriptiveDetails": {
    "targetFiles": [
      {
        "path": ".env.example",
        "action": "MODIFY",
        "description": "Add authentication environment variables"
      }
    ],
    "codePatterns": [
      {
        "file": ".env.example",
        "description": "Environment variables to add",
        "pattern": "# Authentication\nJWT_SECRET=your-256-bit-secret-change-this-in-production\nJWT_EXPIRES_IN=24h\nBCRYPT_ROUNDS=10"
      }
    ]
  },
  "atomicActions": [
    {
      "id": "CONFIG_001",
      "description": "Open .env.example file"
    },
    {
      "id": "CONFIG_002", 
      "description": "Add comment line: # Authentication"
    },
    {
      "id": "CONFIG_003",
      "description": "Add line: JWT_SECRET=your-256-bit-secret-change-this-in-production"
    },
    {
      "id": "CONFIG_004",
      "description": "Add line: JWT_EXPIRES_IN=24h"
    },
    {
      "id": "CONFIG_005",
      "description": "Add line: BCRYPT_ROUNDS=10"
    }
  ]
}
```

### Example 2: Complex Feature Task

See [Complete Authentication Plan Example](../templates/example-auth-plan.json) for a full multi-task plan.

## Best Practices Summary

1. **Make all decisions during planning** - No decisions during implementation
2. **Provide exact code** - Not descriptions or pseudocode
3. **Specify everything** - Versions, paths, names, formats
4. **Think adversarially** - What could be misunderstood?
5. **Test your instructions** - Could someone else implement this exactly?

Remember: If two different developers (human or AI) would implement it differently, your plan isn't prescriptive enough.