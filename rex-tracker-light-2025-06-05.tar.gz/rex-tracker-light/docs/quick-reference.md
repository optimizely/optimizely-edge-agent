# Rex Tracker Light - Quick Reference

## For AI Agents - Start Here

### 1. Check Current State
```bash
cat rex-tracker-light/current/active-plan.json
node rex-tracker-light/scripts/plan-manager.js status
```

### 2. Key Questions to Ask
- Is there an active plan? If not: "Which plan should I work on?"
- Is there a current task? If not: Get next task
- Are there blockers? If yes: Report them
- What's the next atomic action? Execute it

### 3. Standard Workflow
```bash
# Get status
node plan-manager.js status

# If no active plan
node plan-manager.js list-plans
# Ask: "Which plan should I activate?"

# If active plan exists
node plan-manager.js next-task
node plan-manager.js start-task TASK001

# For each atomic action
node plan-manager.js next-action
# Implement the action
node plan-manager.js complete-action TASK001 ACTION001 "Completed successfully"

# When all actions done
node plan-manager.js complete-task TASK001 "All verification criteria met"
```

## For Engineers - Quick Start

### Create a Plan
1. Copy `templates/plan-template.json`
2. Fill in prescriptive details
3. Save as `plans/your-plan-id.json`
4. Activate: `node plan-manager.js set-active your-plan-id`

### Execute a Plan
```bash
# See what's available
node plan-manager.js list-plans

# Start working
node plan-manager.js set-active my-feature
node plan-manager.js next-task
node plan-manager.js start-task TASK001

# Track progress
node plan-manager.js complete-action TASK001 ACTION001
node plan-manager.js status
```

## Key Principles

1. **Plans are prescriptive** - Follow exactly, no interpretation
2. **Atomic actions are checkpoints** - Complete one at a time
3. **Blockers stop work** - Document and report immediately
4. **Context persists** - Everything is saved to files

## Common Commands

| Command | Purpose | Example |
|---------|---------|---------|
| `status` | Check current state | `node plan-manager.js status` |
| `list-plans` | See all plans | `node plan-manager.js list-plans` |
| `set-active` | Switch plans | `node plan-manager.js set-active auth-v2` |
| `next-task` | Get next task | `node plan-manager.js next-task` |
| `start-task` | Begin work | `node plan-manager.js start-task TASK001` |
| `complete-action` | Mark action done | `node plan-manager.js complete-action TASK001 ACTION001` |
| `complete-task` | Finish task | `node plan-manager.js complete-task TASK001` |
| `block-task` | Report blocker | `node plan-manager.js block-task TASK001 "Missing API key"` |

## File Locations

```
rex-tracker-light/
├── plans/              # Implementation plans (*.json)
├── current/            # Current state
│   ├── active-plan.json    # Which plan/task/action
│   └── context.json        # Working context
├── scripts/
│   └── plan-manager.js     # Main CLI tool
└── docs/              # Documentation
```

## Troubleshooting

### "No active plan"
```bash
node plan-manager.js list-plans
node plan-manager.js set-active <plan-id>
```

### "No available tasks"
- Check for blocked tasks: `node plan-manager.js status`
- Check dependencies in plan
- All tasks might be complete

### "Task not found"
- Verify task ID matches plan
- Check active plan is correct

## Remember

- **Read the prescriptive details** before implementing
- **Complete atomic actions in order**
- **Document blockers immediately**
- **Never modify plan files directly** - use the CLI