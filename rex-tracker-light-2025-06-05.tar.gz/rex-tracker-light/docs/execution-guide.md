# Rex Tracker Light - Execution Guide

This guide explains how to work with implementation plans, whether you're an AI agent or human engineer.

## Table of Contents

1. [Starting Work](#starting-work)
2. [Understanding Context](#understanding-context)
3. [Task Execution Protocol](#task-execution-protocol)
4. [Atomic Action Decomposition](#atomic-action-decomposition)
5. [Progress Tracking](#progress-tracking)
6. [Handling Blockers](#handling-blockers)
7. [Switching Plans](#switching-plans)
8. [Common Scenarios](#common-scenarios)

## Starting Work

### First Time Setup

1. **Check if there's an active plan**:
   ```bash
   cat current/active-plan.json
   ```

2. **If no active plan, choose one**:
   ```bash
   # List available plans
   ls plans/
   
   # Review plan summaries
   node scripts/plan-manager.js list-plans
   
   # Set active plan
   node scripts/plan-manager.js set-active auth-system-v2
   ```

3. **Review the plan context**:
   ```bash
   cat current/context.json
   ```

### Resuming Work

1. **Check current state**:
   ```bash
   node scripts/plan-manager.js status
   ```
   
   This shows:
   - Active plan
   - Current task
   - Progress on current task
   - Blocked items

2. **Get next action**:
   ```bash
   node scripts/plan-manager.js next-action
   ```

## Understanding Context

### Reading the Active Plan

The active plan contains everything needed for implementation:

```json
{
  "currentPlan": "auth-system-v2",
  "currentTask": "TASK003",
  "currentAction": 5,
  "lastUpdated": "2025-01-29T10:30:00Z",
  "blockers": [],
  "context": {
    "workingDirectory": "/src/auth",
    "lastCompletedTask": "TASK002",
    "environment": "development"
  }
}
```

### Task Context

Each task provides:
1. **What to build** (description)
2. **How to build it** (prescriptiveDetails)
3. **Steps to follow** (atomicActions)
4. **How to verify** (verificationCriteria)

## Task Execution Protocol

### Step 1: Get Task Details

```bash
# Get current task
node scripts/plan-manager.js get-task

# Or manually
cat plans/auth-system-v2.json | jq '.tasks[] | select(.id=="TASK003")'
```

### Step 2: Review Prescriptive Details

Before starting, understand:
- Required packages and versions
- Exact code patterns to implement
- Target files to create/modify
- Constraints (what NOT to do)

### Step 3: Execute Atomic Actions

For each atomic action:

1. **Mark as started**:
   ```bash
   node scripts/plan-manager.js start-action TASK003 ACTION001
   ```

2. **Implement exactly as specified**

3. **Mark as complete**:
   ```bash
   node scripts/plan-manager.js complete-action TASK003 ACTION001 "Installed jsonwebtoken@9.0.2"
   ```

### Step 4: Verify Completion

After all atomic actions:
1. Check each verification criterion
2. Run specified tests
3. Confirm constraints were followed

### Step 5: Complete Task

```bash
node scripts/plan-manager.js complete-task TASK003 "All criteria met, tests passing"
```

## Atomic Action Decomposition

### What Makes an Action Atomic?

An atomic action:
- Has a single, specific goal
- Can be completed in one step
- Is verifiable
- Has no sub-tasks

### Examples of Atomic Actions

✅ **Good Atomic Actions**:
- "Install package jsonwebtoken@9.0.2"
- "Create file src/middleware/auth.ts"
- "Add import statement: import jwt from 'jsonwebtoken'"
- "Define interface AuthRequest"

❌ **Not Atomic** (need breakdown):
- "Set up authentication" → Too broad
- "Create middleware and add error handling" → Multiple goals
- "Implement login flow" → Many steps

### Creating Atomic Actions

When a task needs breakdown:

1. **List every single step** needed
2. **Order them logically**
3. **Ensure each has one goal**
4. **Make them verifiable**

Example breakdown:
```
Task: "Create auth middleware"
Atomic Actions:
1. Create file src/middleware/auth.ts
2. Add import: express types
3. Add import: jsonwebtoken
4. Define AuthRequest interface
5. Create authMiddleware function signature
6. Add token extraction logic
7. Add token verification logic
8. Add error response for missing token
9. Add error response for invalid token
10. Export authMiddleware function
```

## Progress Tracking

### Automatic Tracking

The plan manager tracks:
- Task status (PENDING → IN_PROGRESS → DONE)
- Atomic action completion
- Time spent
- Implementation notes

### Manual Progress Updates

Add notes about decisions or issues:

```bash
node scripts/plan-manager.js add-note TASK003 "Used Request type extension pattern for TypeScript"
```

### Progress Reporting

Get current progress:

```bash
# Overall plan progress
node scripts/plan-manager.js progress

# Detailed task progress
node scripts/plan-manager.js task-progress TASK003
```

## Handling Blockers

### Types of Blockers

1. **Missing Information**
   - Required detail not in plan
   - Ambiguous specification
   - Missing dependency

2. **Technical Issues**
   - Package conflicts
   - Environment problems
   - Breaking changes

3. **Scope Issues**
   - Need to modify protected file
   - Change would break constraints
   - Requires architectural decision

### Blocker Protocol

1. **Stop immediately** - Don't try to work around it

2. **Document the blocker**:
   ```bash
   node scripts/plan-manager.js add-blocker TASK003 "Package xyz@2.0 conflicts with existing dependency"
   ```

3. **Set task status**:
   ```bash
   node scripts/plan-manager.js update-status TASK003 BLOCKED
   ```

4. **Request help** with specific details:
   - What you were trying to do
   - What went wrong
   - What information/decision is needed

## Switching Plans

### Save Current Context

Before switching:
```bash
node scripts/plan-manager.js save-context "Switching to handle urgent bug fix"
```

### Switch to New Plan

```bash
node scripts/plan-manager.js set-active bugfix-plan-123
```

### Resume Previous Plan

```bash
node scripts/plan-manager.js list-contexts
node scripts/plan-manager.js restore-context auth-system-v2
```

## Common Scenarios

### Scenario 1: Starting Fresh

```bash
# 1. Check available plans
ls plans/

# 2. Choose and activate plan
node scripts/plan-manager.js set-active new-feature-plan

# 3. Get first task
node scripts/plan-manager.js next-task

# 4. Start implementation
node scripts/plan-manager.js start-task TASK001
```

### Scenario 2: Resuming After Break

```bash
# 1. Check where you left off
node scripts/plan-manager.js status

# 2. Review current task progress
node scripts/plan-manager.js task-progress TASK003

# 3. Get next atomic action
node scripts/plan-manager.js next-action

# 4. Continue from that action
```

### Scenario 3: Task Needs More Detail

```bash
# 1. Document what's missing
node scripts/plan-manager.js add-note TASK003 "Need clarification: Should middleware log attempts?"

# 2. Block the task
node scripts/plan-manager.js update-status TASK003 BLOCKED

# 3. Move to next available task
node scripts/plan-manager.js next-task --skip-blocked
```

### Scenario 4: Completed All Tasks

```bash
# 1. Verify plan completion
node scripts/plan-manager.js verify-plan

# 2. Generate completion report
node scripts/plan-manager.js completion-report

# 3. Archive plan
node scripts/plan-manager.js archive-plan auth-system-v2
```

## Best Practices

### For AI Agents

1. **Always read files, never assume**
2. **Follow prescriptive details exactly**
3. **Update progress after EACH atomic action**
4. **Stop at blockers - don't improvise**
5. **Add notes for any deviations**

### For Human Engineers

1. **Review entire task before starting**
2. **Complete atomic actions in order**
3. **Test after each major action**
4. **Document decisions in notes**
5. **Update status promptly**

### Common Mistakes to Avoid

❌ **Don't**:
- Skip atomic actions
- Combine multiple actions
- Make architectural decisions
- Use different package versions
- Ignore constraints

✅ **Do**:
- Follow the plan exactly
- Complete one action at a time
- Verify each step
- Document everything
- Ask when unsure

## Command Reference

See [Command Reference](./command-reference.md) for complete list of plan-manager commands.

## Troubleshooting

See [Troubleshooting Guide](./troubleshooting.md) for common issues and solutions.